import numpy as np
from mpi4py import MPI
from petsc4py import PETSc
from dolfinx import fem, io

import sys

from EX_L_Domain import domain, BCs, VariationalFormulation
from Solvers import Elastic, Damage, alternate_minimization
from NewtonSolver import NewtonSolver

def main(method='AltMin'):
    comm=MPI.COMM_WORLD
    rank=comm.rank
    rtol=1.0e-6
    
    u, v, dom =domain()
    E_u, E_v, E_uu, E_vv, E_uv, E_vu, elastic_energy, dissipated_energy, p, total_energy = VariationalFormulation(u,v,dom)
    bcs_u, bcs_v, uD = BCs(u,v,dom)

    elastic_problem, elastic_solver = Elastic(E_u, u, bcs_u, E_uu)
    damage_problem, damage_solver = Damage(E_v, v, bcs_v, E_vv)

    u_lb = u.x.petsc_vec.duplicate()
    u_ub = u.x.petsc_vec.duplicate()
    v_lb = v.x.petsc_vec.duplicate()
    v_ub = v.x.petsc_vec.duplicate()
    u_lb.array[:]=PETSc.NINFINITY
    u_ub.array[:]=PETSc.INFINITY
    v_lb.array[:]=0.0
    v_ub.array[:]=1.0
    b_lb = PETSc.Vec().createNest([u_lb,v_lb],None,MPI.COMM_WORLD)
    b_ub = PETSc.Vec().createNest([u_ub,v_ub],None,MPI.COMM_WORLD)

    EN=NewtonSolver(elastic_solver, damage_solver,
                    elastic_problem, damage_problem,
                    E_uv, E_vu,
                   'backtrack')
    EN.setUp(rtol=rtol,max_it_SNES=1000,max_it_KSP=100,ksp_restarts=100)
    EN.solver.setVariableBounds(b_lb,b_ub)
    uv = PETSc.Vec().createNest([u.x.petsc_vec,v.x.petsc_vec])#,None,MPI.COMM_WORLD)
    
    loads = np.linspace(0,0.6,81)
    
    # Array to store results
    energies = np.zeros((loads.shape[0], 5 ))
    iter_count=[]
    with io.XDMFFile(dom.comm, f"EX_L_{method}.xdmf","w") as xdmf:
        xdmf.write_mesh(dom)

    for i_t, t in enumerate(loads):
        uD.value=t
        energies[i_t, 0] = t

        if rank==0:
            print(f"-- Solving for t = {t:3.2e} --")
        if method=='NewtonLS':
            EN.solver.solve(None,uv)
            energies[i_t,4] = EN.solver.getIterationNumber()
        else:
            iter_count, iteration = alternate_minimization(u, v, elastic_solver, damage_solver, rtol, 1000, True, iter_count)
            energies[i_t,4] = iteration
        
        # Calculate the energies
        energies[i_t, 1] = comm.allreduce(
            fem.assemble_scalar(fem.form(elastic_energy)),
            op=MPI.SUM,
        )
        energies[i_t, 2] = comm.allreduce(
            fem.assemble_scalar(fem.form(dissipated_energy)),
            op=MPI.SUM,
        )
        energies[i_t, 3] = comm.allreduce(
            fem.assemble_scalar(fem.form(total_energy)),
            op=MPI.SUM,
        )
        with io.XDMFFile(dom.comm, f"EX_L_{method}.xdmf","a") as xdmf:
            xdmf.write_function(u, t)
            xdmf.write_function(v, t)

if __name__ == "__main__":
    main('NewtonLS')
    sys.exit()